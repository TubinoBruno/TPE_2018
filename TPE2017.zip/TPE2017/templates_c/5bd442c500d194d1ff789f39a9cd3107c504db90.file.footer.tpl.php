<?php /* Smarty version Smarty-3.1.14, created on 2017-10-12 16:21:10
         compiled from ".\templates\components\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3228459df5a9f127504-81371108%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5bd442c500d194d1ff789f39a9cd3107c504db90' => 
    array (
      0 => '.\\templates\\components\\footer.tpl',
      1 => 1507817985,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3228459df5a9f127504-81371108',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_59df5a9f12b380_99034323',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59df5a9f12b380_99034323')) {function content_59df5a9f12b380_99034323($_smarty_tpl) {?>

<footer	id="footer">
	<div class="container">
		<p class="text-muted">
			Tubino Bruno - Langiano Nicolás
		</p>
    </div>
</footer>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/mustache.js/2.1.3/mustache.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

 </body>
</html>
<?php }} ?>