<?php /* Smarty version Smarty-3.1.14, created on 2017-10-12 14:05:51
         compiled from ".\templates\components\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1617959df5a9f015e05-42782793%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b3e9f6a0c8b0e8acf8c433b6e4aa7b527aa9b4a1' => 
    array (
      0 => '.\\templates\\components\\header.tpl',
      1 => 1507808455,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1617959df5a9f015e05-42782793',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_59df5a9f015e02_72403596',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59df5a9f015e02_72403596')) {function content_59df5a9f015e02_72403596($_smarty_tpl) {?><!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title> Articulación Social UNICEN </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<link rel="shortcut icon" href="images/favicon.ico">
    <link rel="stylesheet" href="css/main.css">
	</head>
  	<body>
		<header>
			<div class="imageAndText">
					<img src="images/header.jpg" class="img-responsive" alt="libros" id="img-header"/>
					<h1 class="col-md-12 col-md-offset-8">Articulación Social</h1>
			</div>
		</header>
<?php }} ?>