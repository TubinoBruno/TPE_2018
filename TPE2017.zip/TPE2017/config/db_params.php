<?php

class DatabaseConfig {

	public static $DB_LOCATION = 'mysql:host=localhost;dbname=db_2017;charset=utf8';
	public static $DB_USER = 'root';
	public static $DB_PASSWORD = '';
}
?>
